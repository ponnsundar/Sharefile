import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.hadoop.security.UserGroupInformation;

public class ImpalaSampleClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

			
			System.setProperty("java.security.krb5.conf", "/etc/krb5.conf");

			org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
			conf.set("hadoop.security.authentication", "Kerberos");
			UserGroupInformation.setConfiguration(conf);
			UserGroupInformation.loginUserFromKeytab("", "");
			String Impala_CONNECTION_URL = "";//url specific to cloudera driver
			// String autojoin = "set hive.auto.convert.join=false";
			String STATEMENT = "";

			Connection Hivecon = null;

			PreparedStatement ps;

			Class.forName("org.cloudera.impala.jdbc41.Driver");

			Hivecon = DriverManager.getConnection(Impala_CONNECTION_URL);
			Statement stmt = Hivecon.createStatement();
			System.out.println("Started Execution1");

			ps = Hivecon.prepareStatement(STATEMENT);

			// Execute Query
			ResultSet rs = ps.executeQuery();

			System.out.println("Result fetch");

			// Read the result by looping through the result set

			while (rs.next()) {

				String recordCount = rs.getString(1);
				// long recordCount = rs.getLong(1);
				System.out.println("Total Records  : " + recordCount);
			}

			// rs.close();
			ps.close();
			Hivecon.close();

		} catch (SQLException s) {
			System.out.print("Inside Exception" + s);
			s.printStackTrace();

		}
		// catch (IOException e1) {
		// TODO Auto-generated catch block
		// e1.printStackTrace();
		// }
		catch (Exception e) {

			e.printStackTrace();
		}

	}

}
