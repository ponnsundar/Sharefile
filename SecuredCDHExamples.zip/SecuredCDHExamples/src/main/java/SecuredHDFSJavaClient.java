
import java.io.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.security.UserGroupInformation;

class SecuredHDFSJavaClient {
    public static void main(String[] args) throws IOException, FileNotFoundException{
        String path = "/";
        if( args.length > 0 )
            path = args[0];

        
        System.setProperty("java.security.krb5.conf", "/etc/krb5.conf");
        System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
        //System.setProperty("java.security.auth.login.config", "/tmp/jaas.config");
       // System.setProperty("hadoop.security.authentication", "Kerberos");
         //System.setProperty("java.security.krb5.realm", "Hadoop.com" );
        org.apache.hadoop.conf.Configuration conf = new   
        		org.apache.hadoop.conf.Configuration();
        		conf.set("hadoop.security.authentication", "Kerberos");
        		
        		UserGroupInformation.setConfiguration(conf);
        		UserGroupInformation.loginUserFromKeytab("", "");
        		conf.addResource(new Path("/etc/hadoop/conf/core-site.xml"));
        		conf.addResource(new Path("/etc/hadoop/conf/hdfs-site.xml"));
        		/*Configuration configuration = new Configuration(); 
       configuration.set("hadoop.security.authentication", "Kerberos"); 
       configuration.addResource(new Path("/etc/hadoop/conf/core-site.xml"));
        configuration.addResource(new Path("/etc/hadoop/conf/hdfs-site.xml"));*/
         FileSystem fs = FileSystem.get(conf);
       Path outFile = new Path("test");
       FSDataOutputStream out = fs.create(outFile);
        System.out.println("*******************************************Test File System Object**************************************");
        
    }
}