import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.hadoop.security.UserGroupInformation;

public class HiveSampleClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

			//System.setProperty("java.security.auth.login.config", "/path/to/jaas.config");
			System.setProperty("javax.security.auth.useSubjectCredsOnly",
					"true");
			System.setProperty("java.security.krb5.conf", "/path/to/krb5.conf");

			org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
			conf.set("hadoop.security.authentication", "Kerberos");
			UserGroupInformation.setConfiguration(conf);
			UserGroupInformation.loginUserFromKeytab("", "/path/tpkeytab");
			String HIVE_CONNECTION_URL = "";
			String Impala_CONNECTION_URL = "";

			// String autojoin = "set hive.auto.convert.join=false";
			String STATEMENT = "";

			Connection Hivecon = null;

			PreparedStatement ps;

			Class.forName("org.apache.hive.jdbc.HiveDriver");

			Hivecon = DriverManager.getConnection(HIVE_CONNECTION_URL);
			Statement stmt = Hivecon.createStatement();
			System.out.println("Started Execution1");

			/*
			 * boolean resHivePropertyTest = stmt
			 * .execute("set hive.execution.engine=mr"); resHivePropertyTest =
			 * stmt .execute(
			 * "set hbase.zookeeper.quorum =""
			 * ); resHivePropertyTest = stmt
			 * .execute("set hbase.zookeeper.property.clientPort = 2181");
			 * resHivePropertyTest = stmt
			 * .execute("set zookeeper.znode.parent = /hbase-secure");
			 * resHivePropertyTest = stmt
			 * .execute("set hbase.rpc.protection = authentication");
			 */
			ps = Hivecon.prepareStatement(STATEMENT);

			// Execute Query
			ResultSet rs = ps.executeQuery();

			System.out.println("Result fetch");

			// Read the result by looping through the result set

			while (rs.next()) {

				String recordCount = rs.getString(1);
				// long recordCount = rs.getLong(1);
				System.out.println("Total Records  : " + recordCount);
			}

			// rs.close();
			ps.close();
			Hivecon.close();

		} catch (SQLException s) {
			System.out.print("Inside Exception" + s);
			s.printStackTrace();

		}
		// catch (IOException e1) {
		// TODO Auto-generated catch block
		// e1.printStackTrace();
		// }
		catch (Exception e) {

			e.printStackTrace();
		}

	}

}
