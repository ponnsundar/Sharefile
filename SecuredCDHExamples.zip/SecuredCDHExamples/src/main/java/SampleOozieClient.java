import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.Properties;

import org.apache.hadoop.security.UserGroupInformation;
import org.apache.oozie.client.*;

public class SampleOozieClient {

	public static void main(String[] args) throws IOException,
			InterruptedException {
		// OozieClient wc = new OozieClient("");
		/*
		 * System.out.println("Jaas Config"+
		 * System.getProperty("java.security.auth.login.config"));
		 * System.out.println("subject credentials"+
		 * System.getProperty("javax.security.auth.useSubjectCredsOnly"));
		 * System.out.println("Kerberose"+
		 * System.getProperty("java.security.krb5.conf"));
		 */
		// System.setProperty("java.security.auth.login.config",
		// "/root/jaas/jaas.conf");
		// System.setProperty("javax.security.auth.useSubjectCredsOnly",
		// "true");
		// System.setProperty("java.security.krb5.conf", "/etc/krb5.conf");

		// -Djava.security.auth.login.config=/Users/msundaram/Documents/workspace/HiveJDBCSampleClient/src/resources/jaas.conf
		// -Djava.security.krb5.conf=/Users/msundaram/Documents/workspace/HiveJDBCSampleClient/src/resources/krb5.conf
		// -Djavax.security.auth.useSubjectCredsOnly=true

		/*
		 * org.apache.hadoop.conf.Configuration config = new
		 * org.apache.hadoop.conf.Configuration();
		 * config.set("hadoop.security.authentication", "Kerberos");
		 * UserGroupInformation.setConfiguration(config);
		 * UserGroupInformation.loginUserFromKeytab("ms@MS.com",
		 * "/Users/msundaram/keytabs/dev/ms.keytab");
		 */

		org.apache.hadoop.conf.Configuration conf1 = new org.apache.hadoop.conf.Configuration();
		conf1.set("hadoop.security.authentication", "kerberos");
		UserGroupInformation.setConfiguration(conf1);
		UserGroupInformation ugi = UserGroupInformation
				.loginUserFromKeytabAndReturnUGI("prinvipal", "keytab");
		System.out.println("Username:" + UserGroupInformation.getLoginUser());
		final AuthOozieClient wc = new AuthOozieClient("url");
		final Properties conf = wc.createConfiguration();

		conf.setProperty(OozieClient.APP_PATH, "");
		conf.setProperty("jobTracker", "");
		conf.setProperty("nameNode", "");
		conf.setProperty("queueName", "");
		conf.setProperty("oozie.use.system.libpath", "true");
		conf.setProperty("outputDir", "");
		conf.setProperty("examplesRoot", "");
		conf.setProperty("oozie.wf.validate.ForkJoin", "false");
		conf.setProperty("user.name", ugi.getUserName());

		ugi.doAs(new PrivilegedExceptionAction<Void>() {
			public Void run() throws Exception {
				// Submit a job
				String jobId = wc.run(conf);
				// jobIdOut = jobId;

				System.out.println("Workflow job, " + jobId + " submitted");

				while (wc.getJobInfo(jobId).getStatus() == WorkflowJob.Status.RUNNING) {
					System.out.println("Workflow job running ...");
					Thread.sleep(10 * 1000);
				}
				System.out.println("Workflow job completed ...");
				System.out.println(wc.getJobInfo(jobId));

				return null;
			}
		});

		try {/*
			 * 
			 * 
			 * String jobId = wc.run(conf); System.out.println("Workflow job, "
			 * + jobId + " submitted");
			 * 
			 * while (wc.getJobInfo(jobId).getStatus() ==
			 * WorkflowJob.Status.RUNNING) {
			 * System.out.println("Workflow job running ..."); Thread.sleep(10 *
			 * 1000); } System.out.println("Workflow job completed ...");
			 * System.out.println(wc.getJobInfo(jobId));
			 */
		} catch (Exception r) {
			System.out.println(r);
		}
	}
}
