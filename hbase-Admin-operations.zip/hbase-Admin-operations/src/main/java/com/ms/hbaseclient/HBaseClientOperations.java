package com.ms.hbaseclient;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HRegionInfo;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.security.UserGroupInformation;

import com.google.protobuf.ServiceException;

import java.io.IOException;
import java.util.List;

public class HBaseClientOperations {

	public static Configuration createConfig(String configPath)
			throws IOException, ServiceException {
		Configuration clusterConfig = HBaseConfiguration.create();
		clusterConfig.addResource(new Path(configPath));
		try {
			HBaseAdmin.checkHBaseAvailable(clusterConfig);
		} catch (MasterNotRunningException e) {
			System.out.println("HBase is not running." + e.getMessage());
			return null;
		}
		return clusterConfig;
	}

	public static Configuration createConfig(String configPath,
			String princpalName, String keytabLocation) throws IOException,
			ServiceException {
		Configuration clusterConfig = HBaseConfiguration.create();
		System.out.println("Creating config with conf file " + configPath);
		clusterConfig.addResource(new Path(configPath));
		try {
			UserGroupInformation.setConfiguration(clusterConfig);
			UserGroupInformation.loginUserFromKeytab(princpalName,
					keytabLocation);
			System.out
					.println("****************************Logged in successfully****************************");
			HBaseAdmin.checkHBaseAvailable(clusterConfig);
			System.out
					.println("****************************Created config****************************");
		} catch (MasterNotRunningException e) {
			System.out.println("HBase is not running." + e.getMessage());
			return null;
		}

		return clusterConfig;
	}

	public static Connection createConnection(Configuration clusterConfig)
			throws IOException {
		Connection connection = ConnectionFactory
				.createConnection(clusterConfig);
		return connection;
	}

	public static Connection createConnection(Configuration clusterConfig,
			UserGroupInformation ugi) throws IOException {
		ugi.checkTGTAndReloginFromKeytab();
		Connection connection = ConnectionFactory
				.createConnection(clusterConfig);
		return connection;
	}

	public static UserGroupInformation createUGI(Configuration clusterConfig,
			String principalName, String keytabLocation) throws IOException {
		if (clusterConfig == null) {
			System.out.println("config is null");
		}
		UserGroupInformation.setConfiguration(clusterConfig);
		UserGroupInformation ugi = UserGroupInformation
				.loginUserFromKeytabAndReturnUGI(principalName, keytabLocation);
		System.out
				.println("****************************Created UGI****************************");
		return ugi;
	}

	public static void dropTable(Connection connection, TableName table)
			throws IOException {
		Admin admin = connection.getAdmin();

		if (admin.tableExists(table)) {
			admin.disableTable(table);
			admin.deleteTable(table);
		}
	}

	public static void majorCompactRegion(Admin admin, byte[] regionName)
			throws IOException {
		admin.majorCompactRegion(regionName);
	}

	public static void majorCompactTable(Admin admin, TableName tableName)
			throws IOException {

		admin.majorCompact(tableName);
		;
	}

	public static void analyzeTable(Connection connection, TableName tbl)
			throws IOException {
		// TODO Auto-generated method stub
		Admin admin = connection.getAdmin();
		List<HRegionInfo> hr = admin.getTableRegions(tbl);
		for (HRegionInfo hi : hr) {
			System.out.println(hi.getRegionNameAsString() + "\t "
					+ hi.getStartKey().toString() + "\t "
					+ hi.getEndKey().toString());

		}
	}

}
