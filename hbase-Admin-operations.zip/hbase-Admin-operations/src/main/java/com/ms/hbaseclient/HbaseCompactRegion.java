package com.ms.hbaseclient;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HRegionInfo;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.protobuf.generated.AdminProtos.GetRegionInfoResponse.CompactionState;
import org.apache.hadoop.security.UserGroupInformation;

import com.google.protobuf.ServiceException;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class HbaseCompactRegion {
	public static void main(String[] args) throws IOException,
			ServiceException, InterruptedException {

		if (args.length <= 0 || args.length > 1) {
			System.out
					.println("Please provide Config file Path: java -classpath <jarFilePath> com.ms.hbaseclient.HbaseCompactRegion <ConfigFilePAth>");
			System.exit(0);
		}
		System.setProperty("java.security.krb5.conf", "/etc/krb5.conf");
		System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
		Config typesafeconfig = ConfigFactory.parseFile(new File(args[0]));
		String srcClusterConfigPath = typesafeconfig
				.getString("compareHbaseTable.srcConfigPath");
		String tableName = typesafeconfig
				.getString("compareHbaseTable.tableName");
		String principalName = typesafeconfig
				.getString("compareHbaseTable.principalName");
		String keyTabLocation = typesafeconfig
				.getString("compareHbaseTable.keytabLocation");

		TableName tbl = TableName.valueOf(tableName);
		/*
		 * Configuration srcClusterConfig = HBaseClientOperations
		 * .createConfig(srcClusterConfigPath); Connection srcClusterConnection
		 * = HBaseClientOperations .createConnection(srcClusterConfig);
		 */

		Configuration srcClusterConfig = HBaseClientOperations.createConfig(
				srcClusterConfigPath, principalName, principalName);

		UserGroupInformation ugi = HBaseClientOperations.createUGI(
				srcClusterConfig, principalName, principalName);
		Connection srcClusterConnection = HBaseClientOperations
				.createConnection(srcClusterConfig, ugi);

		new HbaseCompactRegion().compactRegion(srcClusterConfig, tbl,
				typesafeconfig, srcClusterConnection, ugi);

	}

	public void compactRegion(Configuration srcClusterConfig,
			TableName srcTblName, Config typesafeconfig,
			Connection srcClusterConnection, UserGroupInformation ugi)
			throws IOException, InterruptedException {

		Admin admin = srcClusterConnection.getAdmin();

		List<HRegionInfo> srcTableRegions = admin.getTableRegions(srcTblName);

		HBaseClientOperations.majorCompactTable(admin, srcTblName);
		// scan 'hbase:meta',{FILTER=>"PrefixFilter('sks_notes:scoring')"}
		for (HRegionInfo regionInfo : srcTableRegions) {

			System.out.println(regionInfo.getEncodedName() + "\t "
					+ regionInfo.getStartKey().toString() + "\t "
					+ regionInfo.getEndKey().toString());
			System.out.print("Started Compacting Region:"
					+ regionInfo.getEncodedName());
			long startTime = System.nanoTime();
			HBaseClientOperations.majorCompactRegion(admin, regionInfo
					.getEncodedName().getBytes());

			CompactionState Value = admin
					.getCompactionStateForRegion(regionInfo.getEncodedName()
							.getBytes());
			Thread.sleep(30000);
			do {

				Value = admin.getCompactionState(srcTblName);
				Thread.sleep(30000);
				System.out.print("Still Compacting Region"
						+ regionInfo.getEncodedName() + Value.toString());
				srcClusterConnection.close();
				srcClusterConnection = HBaseClientOperations.createConnection(
						srcClusterConfig, ugi);

				admin = srcClusterConnection.getAdmin();

			} while (!("NONE".equalsIgnoreCase(Value.toString())));
			long endTime = System.nanoTime();
			long timeElapsed = endTime - startTime;
			System.out.print("Completed Compacting Region:"
					+ regionInfo.getEncodedName()
					+ ".Current Compaction State:"
					+ Value.toString()
					+ "."
					+ "Total time for compaction(minutes) :"
					+ TimeUnit.MINUTES.convert(timeElapsed,
							TimeUnit.NANOSECONDS));

			srcClusterConnection.close();

		}

	}

}
